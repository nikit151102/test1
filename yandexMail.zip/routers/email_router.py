from fastapi import APIRouter, HTTPException, UploadFile, File, Depends,Form
from fastapi_mail import FastMail, MessageSchema
from config import conf,conf2
from pydantic import BaseModel, EmailStr
from database.database_app import get_session
import schemas
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import UUID
import crudEmail
import defs_send_emails
import openpyxl
import re
from io import BytesIO 
from datetime import datetime
from models import EmailRecord
from sqlalchemy import  select
import asyncio  
from typing import Optional
import random
import pytz
from fastapi import BackgroundTasks
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.date import DateTrigger
import logging

# Настройка логирования
logging.basicConfig(
    filename="email_sending.log",
    level=logging.INFO,
    format="%(asctime)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    encoding="utf-8",
)

router = APIRouter()

# # Инициализация APScheduler
# scheduler = BackgroundScheduler()
# scheduler.start()


class TextMessageRequest(BaseModel):
    email: EmailStr
    subject: str
    message: str

class EmailRecordCreate(BaseModel):
    email: str

    class Config:
        orm_mode = True


# Эндпоинт для получения всех email записей
@router.get("/", response_model=list[schemas.EmailRecord])
async def get_emails(skip: int = 0, limit: int = 10, db: AsyncSession = Depends(get_session)):
    db_emails = await crudEmail.get_emails_to_db(db=db, skip=skip, limit=limit)
    return db_emails


# Эндпоинт для создания email записи
@router.post("/", response_model=schemas.EmailRecord)
async def create_email_endpoint(email_request: EmailRecordCreate, db: AsyncSession = Depends(get_session)):
    db_email = await crudEmail.add_email_to_db(db=db, email=email_request.email)
    return db_email




from typing import List, Union
from sqlalchemy.exc import SQLAlchemyError

def is_valid_email(email: str) -> bool:
    email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return bool(re.match(email_regex, email))

# Модель для неудачных записей
class FailedRecord(BaseModel):
    email: str
    error: str

# Функция для извлечения email из первого столбца первого листа Excel
def extract_emails_from_excel(file_content: bytes):
    # Загружаем Excel файл с помощью openpyxl
    try:
        workbook = openpyxl.load_workbook(filename=BytesIO(file_content))
        sheet = workbook.active  # Получаем активный лист
    except Exception as e:
        raise HTTPException(status_code=400, detail="Error reading Excel file")

    emails = []
    for row in sheet.iter_rows(min_row=2, min_col=1, max_col=1):  # Начинаем с 2-й строки (для пропуска заголовков)
        cell_value = row[0].value
        if cell_value and isinstance(cell_value, str):
            # Проверяем, является ли значение валидным email
            if re.match(r"[^@]+@[^@]+\.[^@]+", cell_value):
                emails.append(cell_value)
            else:
                print(f"Invalid email skipped: {cell_value}")  # Логируем невалидный email
        else:
            print(f"Invalid or empty cell skipped: {cell_value}")  # Логируем пустые или невалидные ячейки

    return emails

def is_valid_email(email: str) -> bool:
    email_regex = r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$'
    return bool(re.match(email_regex, email))

# Модель для неудачных записей
class FailedRecord(schemas.BaseModel):
    email: str
    error: str



@router.post("/all", response_model=dict)
async def create_email_records(file: UploadFile = File(...), db: AsyncSession = Depends(get_session)):
    # Читаем файл
    file_content = await file.read()

    print("File content:", file_content)  # Выводим содержимое файла для отладки

    # Извлекаем email адреса
    emails = extract_emails_from_excel(file_content)

    if not emails:
        raise HTTPException(status_code=400, detail="No valid emails found in the Excel file")

    # Логируем найденные email-адреса
    print(f"Found emails: {emails}")

    # Сохраняем в базе данных
    email_records = []
    failed_records = []
    skipped_count = 0
    invalid_count = 0

    for email in emails:
        try:
            # Проверяем формат email перед добавлением в БД
            if not is_valid_email(email):
                invalid_count += 1
                failed_records.append({'email': email, 'error': 'Invalid email format'})
                continue

            # Проверяем, существует ли уже такой email в базе данных
            result = await db.execute(select(EmailRecord).filter(EmailRecord.email == email))
            existing_email = result.scalar()

            if existing_email:
                skipped_count += 1
                failed_records.append({'email': email, 'error': 'Email already exists'})
                continue

            # Создаем запись email с автоматическим значением для даты
            db_record = EmailRecord(
                email=email,
                date=datetime.utcnow()  # Устанавливаем текущую дату для поля date
            )

            db.add(db_record)
            print(f"Email {email} added successfully")  # Логируем добавление email
            email_records.append(db_record)

        except Exception as e:
            # Логируем ошибку на уровне вставки
            print(f"Error while adding email {email}: {str(e)}")
            failed_records.append({'email': email, 'error': str(e)})

    # Сохраняем изменения в БД
    try:
        await db.commit()
        print(f"Committed successfully")
    except SQLAlchemyError as e:
        await db.rollback()  # Откатим транзакцию в случае ошибки
        print(f"Error during commit: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error saving email records to DB: {str(e)}")
    finally:
        await db.close()  # Закрытие сессии с await

    # Подсчет успешных записей
    loaded_count = len(email_records)

    # Формируем итоговый ответ
    response = {
        "loaded": loaded_count,
        "skipped": skipped_count,
        "invalid": invalid_count,
        "failed_records": [FailedRecord(**record) for record in failed_records]
    }

    return response







# Эндпоинт для удаления одной email записи
@router.delete("/{email_id}", response_model=schemas.EmailRecord)
async def delete_email(email_id: UUID, db: AsyncSession = Depends(get_session)):
    try:
        db_email = await crudEmail.delete_email_from_db(db=db, email_id=email_id)
        return db_email
    except HTTPException as e:
        raise e
    except Exception as e:
        print(f"Error occurred: {str(e)}")
        raise HTTPException(status_code=500, detail="Error deleting the email")

# Эндпоинт для изменения email записи
@router.put("/{email_id}", response_model=schemas.EmailRecord)
async def update_email(email_id: UUID, email_request: schemas.EmailRecordCreate, db: AsyncSession = Depends(get_session)):
    db_email = await crudEmail.update_email_in_db(db=db, email_id=email_id, new_email=email_request.email)
    return db_email




# @router.post("/schedule-send-messages")
# async def schedule_send_bulk_message(
#     subject: str = Form(...),
#     message: str = Form(...),
#     file: UploadFile = File(...),
#     send_date: datetime = Form(...),  # Дата и время для планируемой отправки
#     min_interval: int = Form(...),  # Минимальный интервал в секундах
#     max_interval: int = Form(...),  # Максимальный интервал в секундах
#     emailsPerPage: int = Form(...),  # Количество писем на страницу
#     db: AsyncSession = Depends(get_session),  # Используется ваша сессия для работы с БД
# ):
#     try:

#         # Используем переданное время без изменений
#         send_date_barnaul = send_date

      
#         # Преобразуем файл в base64
#         file_base64 = await defs_send_emails.encode_file_to_base64(file)

#         # Получаем расширение файла и MIME-тип
#         file_extension = file.filename.split('.')[-1].lower()
#         mime_type = defs_send_emails.get_mime_type(file_extension)

#         # Извлекаем все email из базы данных
#         emails = await defs_send_emails.get_emails_from_db(db)

#         if not emails:
#             raise HTTPException(status_code=404, detail="No emails found in the database")

#         # Закрываем сессию после получения данных
#         await db.close()

#         # Определение задачи для APScheduler
#         def scheduled_send_email_task():
#             try:
             
#                 asyncio.run(process_email_batches())
#             except Exception as e:
#                 print(f"Error during scheduled task: {str(e)}")

#         scheduler.add_job(
#             scheduled_send_email_task,
#             DateTrigger(run_date=send_date_barnaul),  # Используем переданное время без изменений
#         )

#         return {"status": f"Email sending scheduled for {send_date_barnaul}"}

#     except Exception as e:
       
#         raise HTTPException(status_code=500, detail=f"Error scheduling email sending: {str(e)}")


@router.post("/send-messages")
async def send_bulk_message(
    background_tasks: BackgroundTasks,  # Добавляем BackgroundTasks
    subject: str = Form(...),
    message: str = Form(...),
    file: UploadFile = File(...),
    min_interval: int = Form(...),  # Минимальный интервал в секундах
    max_interval: int = Form(...),  # Максимальный интервал в секундах
    emailsPerPage: int = Form(...),  # Количество писем на страницу
    db: AsyncSession = Depends(get_session),  
):
    try:
        print('send-messages')
        # Преобразуем файл в base64
        file_base64 = await defs_send_emails.encode_file_to_base64(file)

        # Получаем расширение файла и MIME-тип
        file_extension = file.filename.split('.')[-1].lower()
        mime_type = defs_send_emails.get_mime_type(file_extension)

        # Извлекаем все email из базы данных
        emails = await defs_send_emails.get_emails_from_db(db)

        if not emails:
            raise HTTPException(status_code=404, detail="No emails found in the database")

        # Закрываем сессию после получения данных
        await db.close()

        # Добавляем задачу в фон
        background_tasks.add_task(
            process_email_batches,
            emails=emails,
            subject=subject,
            message=message,
            file_base64=file_base64,
            mime_type=mime_type,
            min_interval=min_interval,
            max_interval=max_interval,
            emailsPerPage=emailsPerPage
        )

        # Немедленный ответ
        return {"status": "Email sending started"}
    
    except Exception as e:
        # Логируем ошибку
        print(f"Error occurred: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error initiating email sending: {str(e)}")


async def process_email_batches(
    emails,
    subject,
    message,
    file_base64,
    mime_type,
    min_interval,
    max_interval,
    emailsPerPage
):
    fm = FastMail(conf)
    errors = []

    # Пагинация: разбиваем список emails на части, по числу emailsPerPage
    email_batches = [emails[i:i + emailsPerPage] for i in range(0, len(emails), emailsPerPage)]

    # Отправляем пачки сообщений с интервалом
    for batch_index, batch in enumerate(email_batches, start=1):
        sent_count = 0
        failed_count = 0

        for email in batch:
            try:
                result = await defs_send_emails.send_email_with_attachment(fm, subject, message, file_base64, mime_type, email)
                print(f"Sending to {email}: {result}")

                if result is True:
                    sent_count += 1
                else:
                    errors.append({"email": email, "error": result})
                    failed_count += 1
            except Exception as e:
                errors.append({"email": email, "error": str(e)})
                failed_count += 1

        # Логируем результаты обработки текущей пачки
        logging.info(
            f"Пакет {batch_index}: {sent_count} писем успешно отправлено, {failed_count} писем не удалось отправить."
        )


        # Генерация случайного интервала от min_interval до max_interval
        random_interval = random.randint(min_interval, max_interval)
        print('random_interval', random_interval)
        await asyncio.sleep(random_interval)  # Ждем случайный интервал в секундах перед отправкой следующей пачки

    if errors:
        # Логируем ошибки отправки
        for error in errors:
            logging.error(f"Не удалось отправить письмо на адрес {error['email']}: {error['error']}")



@router.post("/send-custom-message")
async def send_custom_message(
    email: str = Form(...),
    subject: str = Form(...),
    message: str = Form(...),
    file: Optional[UploadFile] = File(None),
):
    """
    Эндпоинт для отправки кастомного email с возможным вложением файла.
    """
    # Проверяем наличие файла
    if file:
        # Преобразуем файл в base64
        file_base64 = await defs_send_emails.encode_file_to_base64(file)

        # Получаем расширение файла и MIME-тип
        file_extension = file.filename.split('.')[-1].lower()
        mime_type = defs_send_emails.get_mime_type(file_extension)

        # Создаем сообщение с вложением
        body = f"""
            <img src="data:{mime_type};base64,{file_base64}" alt="Image">
            <p>{subject}</p>
            <p>{message}</p>
        """
    else:
        # Создаем сообщение без вложения
        body = f"<p>{message}</p>"

    # Используем функцию для отправки письма
    return await send_email(
        subject = subject,
        recipients=[email],
        body=body
    )




@router.post("/submit-franchise-request/")
async def submit_form(
    full_name: str = Form(...),
    phone: str = Form(...),
    email: EmailStr = Form(...),  # Используем тип EmailStr для валидации email
    ownership_type: str = Form(...),
    planned_investments: str = Form(...),
    premises_type: str = Form(...),
    franchise_source: str = Form(...),
    db: AsyncSession = Depends(get_session)  # Функция для получения сессии базы данных
):
    """
    Эндпоинт для отправки данных с формы и сохранения заявки в базе данных.
    """
    # Получаем текущую дату и время в часовом поясе Новосибирска
    novosibirsk_tz = pytz.timezone("Asia/Novosibirsk")
    current_time = datetime.now(novosibirsk_tz).strftime("%d.%m.%Y %H:%M")

    # Добавляем данные заявки в базу данных
    try:
        new_request = await crudEmail.add_franchise_request_to_db(
            db, full_name, phone, email, ownership_type, planned_investments, premises_type, franchise_source
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Ошибка при сохранении заявки в базе данных: {str(e)}")

    # Создаем тело письма для отправки
    body = f"""
    <h2>Новая заявка на франшизу</h2>
    <p><b>ФИО:</b> {full_name}</p>
    <p><b>Телефон:</b> {phone}</p>
    <p><b>Электронная почта:</b> {email}</p>
    <p><b>Форма собственности:</b> {ownership_type}</p>
    <p><b>Планируемые инвестиции:</b> {planned_investments}</p>
    <p><b>Помещение:</b> {premises_type}</p>
    <p><b>Источник информации о франшизе:</b> {franchise_source}</p>
    <p><b>Дата отправки:</b> {current_time}</p>
    """

    # Инициализируем FastMail с конфигурацией из conf2
    fm = FastMail(conf2)

    try:
        # Создаем сообщение для отправки
        email_message = MessageSchema(
            subject="Новая заявка на франшизу",
            recipients=[conf2.MAIL_FROM],  # Здесь теперь получатель письма - это email из conf2
            body=body,
            subtype="html",  # Отправляем как HTML
        )
        # Отправляем письмо
        await fm.send_message(email_message)
        return {"message": "Заявка успешно отправлена!"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Произошла ошибка при отправке письма: {str(e)}")

async def send_email(subject: str, recipients: list, body: str):
    """
    Функция для отправки письма через FastMail.
    
    :param subject: Тема письма.
    :param recipients: Список адресов получателей.
    :param body: Тело письма в формате HTML или текста.
    """
    # Инициализируем FastMail
    fm = FastMail(conf)

    try:
        email_message = MessageSchema(
            subject=subject,
            recipients=recipients,
            body=body,
            subtype="html",
        )
        await fm.send_message(email_message)
        return {"status": "Email sent successfully"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error sending email: {str(e)}")
    