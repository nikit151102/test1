document.addEventListener("DOMContentLoaded", () => {
    // Проверяем, был ли ранее установлен флаг для обновления страницы
    console.log('localStorage.getItem("isPageReloaded"):', localStorage.getItem("isPageReloaded"));

    // Если страница уже была перезагружена ранее
    if (localStorage.getItem("isPageReloaded") === "true") {
        localStorage.removeItem("isPageReloaded");  // Убираем флаг после проверки
        console.log('Page reload detected (flag removed)');
    } else {
        // Если это первое посещение или обновление страницы
        console.log('First page load or reload detected');

        // Прокручиваем в начало страницы
        window.scrollTo(0, 0);
        
        setTimeout(() => {
            document.body.style.overflow = 'auto';  // Включаем прокрутку
            console.log('Body scroll enabled after reload');
        }, 500);
        
        // Устанавливаем флаг, что страница перезагружена
        localStorage.setItem("isPageReloaded", "true");
    }

    // Включаем прокрутку при любом другом случае
    if (performance.getEntriesByType("navigation")[0]?.type !== "reload") {
        document.body.style.overflow = 'auto'; // Включаем прокрутку
    }
});

// Слушаем событие перед уходом с текущей страницы или обновлением
window.addEventListener("beforeunload", () => {
    // Устанавливаем флаг, что страница перезагружена
    localStorage.setItem("isPageReloaded", "true");
});
