from fastapi import APIRouter, Depends,Form, HTTPException
from database.database_app import get_session
import schemas
from sqlalchemy.ext.asyncio import AsyncSession
from uuid import UUID
import crudEmail, logging
from typing import List


router = APIRouter()

# Настройка логирования
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@router.post("/franchise-request/", response_model=schemas.FranchiseRequestInDB)
async def create_franchise_request(
    full_name: str = Form(...),
    phone: str = Form(...),
    email: str = Form(...),
    ownership_type: str = Form(...),
    planned_investments: str = Form(...),
    premises_type: str = Form(...),
    franchise_source: str = Form(...),
    db: AsyncSession = Depends(get_session)
):
    """Создание новой заявки на франшизу"""

    # Логируем полученные данные
    logger.info(f"Получена новая заявка: {full_name}, {phone}, {email}, {ownership_type}, {planned_investments}, {premises_type}, {franchise_source}")


    new_request = await crudEmail.create_franchise_request(
        db, full_name, phone, email, ownership_type, planned_investments, premises_type, franchise_source
    )
    return new_request  # Возвращаем Pydantic модель



@router.get("/franchise-requests/", response_model=List[schemas.FranchiseRequestInDB])
async def get_franchise_requests(
    skip: int = 0, limit: int = 10, db: AsyncSession = Depends(get_session)
):
    """Получение списка заявок на франшизу"""
    requests = await crudEmail.get_franchise_requests(db, skip, limit)
    return requests



@router.get("/franchise-request/{request_id}", response_model=schemas.FranchiseRequestInDB)
async def get_franchise_request_by_id(
    request_id: UUID, db: AsyncSession = Depends(get_session)
):
    """Получение заявки по ID"""
    request = await crudEmail.get_franchise_request_by_id(db, request_id)
    return request



@router.put("/franchise-request/{request_id}", response_model=schemas.FranchiseRequestInDB)
async def update_franchise_request(
    request_id: UUID,
    full_name: str = Form(None),
    phone: str = Form(None),
    email: str = Form(None),
    ownership_type: str = Form(None),
    planned_investments: str = Form(None),
    premises_type: str = Form(None),
    franchise_source: str = Form(None),
    db: AsyncSession = Depends(get_session)
):
    """Обновление данных заявки"""
    updated_request = await crudEmail.update_franchise_request(
        db, request_id, full_name, phone, email, ownership_type, planned_investments, premises_type, franchise_source
    )
    if updated_request is None:
        raise HTTPException(status_code=400, detail="Не было обновлено ни одно поле")
    return updated_request  # Возвращаем обновленную Pydantic модель




@router.delete("/franchise-request/{request_id}", response_model=schemas.FranchiseRequestInDB)
async def delete_franchise_request(
    request_id: UUID, db: AsyncSession = Depends(get_session)
):
    """Удаление заявки по ID"""
    deleted_request = await crudEmail.delete_franchise_request(db, request_id)
    return deleted_request  # Возвращаем удаленную Pydantic модель



